message="Your name";
document.write("Username: ",prompt(message)+"<br>");
message="Your email";
document.write("Email addreess: ",prompt(message)+"<br>");
message="Your interests";
document.write("Product interests: ",prompt(message)+"<br>");
message="Your Birthday";
document.write("Birthday: ",prompt(message));